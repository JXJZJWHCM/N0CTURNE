# N0cturne · DeepSeek Harness 插件（v0.6.0）

给 DeepSeek Harness（DSH）用的测绘插件。它本身不扫描、不联网探测——只把请求发给
N0cturne 的测绘服务（默认 `https://api.xuankunsec.com`），把结果整理成测绘引擎口径的表格/档案给模型看。

## 一、包里有什么

```
n0cturne-dsh-plugin-0.6.0/
├── package.json          # 插件清单（DSH bundle 声明）
├── lib/index.js          # 插件本体（五个工具，单文件）
├── cordis.patch.yml      # 挂载配置模板（baseUrl / apiKey / 超时）
└── README.md             # 本文件
```

**不需要额外装依赖**：`@deepseek-ai/dsh-tools`、`@deepseek-ai/schemastery` 由 DSH
运行时自己提供（插件由 DSH 的 loader 加载，走它的模块解析）。
若某些精简版 DSH 报 `Cannot find package '@deepseek-ai/dsh-tools'`，
把该 DSH 安装目录 `node_modules/@deepseek-ai/` 下对应包复制到本插件目录即可。

**不含**：任何 API Key、账号、密钥、缓存的扫描结果。装好后需要自己配一把 key（见第三节）。

## 二、安装

### 1. 解压到插件目录

```bash
# Linux/macOS
mkdir -p ~/.dsh/profiles/web/node_modules/@n0cturne
cp -r n0cturne-dsh-plugin-0.6.0 ~/.dsh/profiles/web/node_modules/@n0cturne/dsh-plugin

# Windows PowerShell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.dsh\profiles\web\node_modules\@n0cturne"
Copy-Item .\n0cturne-dsh-plugin-0.6.0 "$env:USERPROFILE\.dsh\profiles\web\node_modules\@n0cturne\dsh-plugin" -Recurse
```

> 把 `web` 换成你实际用的 profile 名（`~/.dsh/profiles/` 下有几个就用哪个，
> 常见是 `web`、`desktop`、`headless`）。多个 profile 都装就各复制一份。

### 2. 在 profile 的 package.json 里登记

打开 `~/.dsh/profiles/<profile>/package.json`，确保两处有它：

```json
{
  "dependencies": {
    "@n0cturne/dsh-plugin": "file:./node_modules/@n0cturne/dsh-plugin"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "@n0cturne/dsh-plugin"
      ]
    }
  }
}
```

> 如果你用 pnpm 管理 profile，也可以直接：
> `cd ~/.dsh/profiles/web && pnpm add file:/path/to/n0cturne-dsh-plugin-0.6.0`
> 然后再把 `"@n0cturne/dsh-plugin"` 加进 `dsh.profile.bundles`。

### 3. 在 profile 的 cordis.patch.yml 末尾追加挂载（含配置）

```yaml
- insert:
    - id: tool-n0cturne
      name: "@n0cturne/dsh-plugin"
      config:
        baseUrl: https://api.xuankunsec.com
        apiKey: ""          # ← 拿到 key 后填这里，见第三节
        timeoutMs: 600000
        pollMs: 3000
```

> 注意：YAML 数组里**裸 `- id:` 是"覆盖已有配置行"**，新加的行必须包在 `- insert:` 下面，
> 否则 DSH 会报 "not found"。

### 4. 重启 DSH

插件在 DSH 进程启动时加载。重启后，让 agent 试一句：

> 查一下 223.5.5.5

能看到资产表就说明装好了。

## 三、配置 API Key（必须）

服务端 `/api/*` 要鉴权。两种拿 key 的方式：

**A. 让 agent 用 `n0cturne_init` 换（需要官网账号密码）**

> 用 n0cturne_init 帮我换一把 key，账号 xxx

插件会 POST `/api/init`，返回一次性的 `nk_...` key，并提示你把它填进插件配置的 `apiKey`。

**B. 找服务管理员要一把**

拿到后填到第 3 步 `cordis.patch.yml` 的 `apiKey`，重启 DSH。

> key 只显示一次，别贴到聊天记录/仓库里；本包不附带任何 key。

## 四、五个工具

| 工具 | 用途 | 主要参数 | 示例说法 |
|---|---|---|---|
| `n0cturne_init` | 账号密码换 API Key | `account`、`password`、`format` | "用 n0cturne_init 换 key" |
| `n0cturne_ip` | IP 实体档案 | `ip`、`detail`、`format`、`ports` | "查 8.8.8.8"、"看 1.1.1.1 详情" |
| `n0cturne_domain` | 域名实体档案 | `domain`、`detail`、`format`、`ports` | "扫一下 baidu.com" |
| `n0cturne_query` | 资产检索（键=值 / 全文 / 分页） | `q`、`page`、`limit`、`mode`、`format` | "查 port:443 product:nginx" |
| `n0cturne_company` | 企业归属扩线 | `name`、`limit` | "腾讯有哪些资产" |

**输出形态**

- 默认（`detail=false`）：**资产表**，一行一个 `ip:port`：
  `ip:port | proto | service/product | title | domain | country | org | evidence`
- `detail=true`：实体档案（端口 / 协议 / 证书 / 归属 / DNS / 风险，分节文本）
- `format=json`：机器可读结构（query 用 `format=json`）

**检索语法（n0cturne_query）**

```
port:443 product:nginx        空格 = AND
product:nginx,apache          逗号 = OR
port:443 -tag:cdn             前导 - = 取反
ip:59.111.0.0/24              IP 段
cert:example.com             证书域名
cve:CVE-2024-6387            漏洞
org:Cloudflare               归属
只写 nginx                     全文检索
```

常用键：`port product service version title banner tech cert domain cve cvss epss
org asn country city icp header favicon content_type tag js_file dns_txt spf dmarc subdomain`。

## 五、常见问题

| 现象 | 原因 / 处理 |
|---|---|
| `N0cturne 拒绝访问：API Key 缺失或无效` | `apiKey` 没填或 key 失效。重新 `n0cturne_init` 或找管理员 |
| `报告 xxx 字符，超过会话输出上限` | 档案太大，插件已把全文存到本地文件并在回复里给路径；改用 `detail=false` 或按需看某段 |
| 扫描很慢 | 默认全端口 1-65535，单目标 1~3 分钟属正常；只要关键端口可在请求里传 `ports` |
| `N0cturne 服务不可达` | 检查本机网络能否访问 `https://api.xuankunsec.com`；CDN/防火墙拦截 UA 时插件已自带 UA |
| 表里 `-` 很多 | 目标不通/被防护设备接管，或该端口没有应用层应答；看 `evidence` 列判断证据类型 |
| 安装后工具没出现 | ①`dsh.profile.bundles` 没加；②没重启 DSH；③`node_modules` 目录层级不对（应能直接看到 `package.json`） |

## 六、版本

- 0.6.0：五个工具拆分（ip/domain/query/company/init）；资产表口径对齐测绘引擎；
  检索支持分页与全文；超长档案自动落盘。
